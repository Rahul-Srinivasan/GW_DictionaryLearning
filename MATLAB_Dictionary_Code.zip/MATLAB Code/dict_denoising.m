function [f,ftv,f1]=dict_denoising(y,D,w,o,lambda)
%% ----------------------------------------
%{
    y: noisy signal
    D: dictionary
    w: patch size
    o: overlapping
    lambda: regularization parameter
 %}

l = length(y);
%% Segment the signal
    %disp('Segmenting signal')
    [Y,Y_i]=segment_test(y,w,w-o);
%    fprintf('Number of segments: %g\n',size(Y,2))
%% Dictionary denoising
    %disp('Dicitonary denoising')
    Y1=dictionary_denoising_lasso(Y,D,lambda);
%% Average coincident samples
    %disp('Patch averaging')
%     [f,ftv,f1]=patch_averaging(Y_i,Y1);
%      [f,ftv,f1]=patch_averaging1(Y_i,Y1);
       [f,ftv,f1] =patch_averaging2(Y_i,Y1,l);


function [f,alpha]=dictionary_denoising_lasso(Y,D,lambda)
%% Calculate denoising for each patch in Y with the LASSO
% Y: Noise signal patches
% D: Dictionary
% f: Reconstructed patches
[m,l]=size(Y);
f=zeros(m,l);
[n,k]=size(D);
alpha=zeros(l,k);

%disp('Dictionary denoising')
parfor i=1:l
    B=lasso(D,Y(:,i),'lambda',lambda);

%     [u,d,err]=LASSOSB(Y(:,i),D,[lambda*200,1e-4]);
     alpha(i,:)=B';
%       alpha(i,:)=d';

% fprintf('it. %g\n',i)
%     [ut,B,Err]=LASSOSB(Y(:,i),D,[10,1e-3]);
    f(:,i)=D*B;
%     f(:,i)=D*d;

end
alpha=alpha';
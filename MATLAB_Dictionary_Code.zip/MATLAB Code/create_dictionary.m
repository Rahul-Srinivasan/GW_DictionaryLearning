function D=create_dictionary(x,w,p,options,learned)
%%Create a dictonary of q atoms of length w
%w:pach length
%p: number atoms in Dictionary
%np: number of paches
%q: number of random patches
%k: desired sparsity
[n,m]=size(x);
disp('Dictionary creation')
if nargin<3
    p=n/w*m;
    options='seq';
    learned=0;
end
if nargin<4
    options='seq';
    learned=0;
end

%Initializa variables
k=4;
disp('Getting patches')
if strcmp(options,'seq')
    X=x(:);
    Y=reshape(X,w,n/w*m);
    Y=Y(:,1:p);
    D=Y;
elseif strcmp(options,'random')
    np=20*p;
    q=3*np;
    Y=zeros(w,q);
    
    l=floor(rand(q,1)*(n-w))+1;
    
    for j=1:q
        
        j_r=floor(rand(1,1)*m)+1;
        %disp([l(j), l(j)+w-1, j_r]) %%%
        a=x(l(j):l(j)+w-1,j_r);
        while norm(a)==0
            j_r=floor(rand(1,1)*m)+1;
            a=x(l(j):l(j)+w-1,j_r);
        end
        Y(:,j)=a;
    end
end


if learned
    disp('Learning')
    Y = Y - repmat( mean(Y), [w 1] );
    [tmp,I] = sort(sum(Y.^2), 'descend');
    Y = Y(:,I(1:np));
    ProjC = @(D)D ./ repmat( sqrt(sum(D.^2)), [w, 1] );
    sel = randperm(np); sel = sel(1:p);
    
    D0 = ProjC( Y(:,sel) );
    D = D0;
   

    X=zeros(p,np);
    select = @(A,k)repmat(A(k,:), [size(A,1) 1]);
    ProjX = @(X,k)X .* (abs(X) >= select(sort(abs(X), 'descend'),k));
    
    %EXO
    %% Perform the iterative hard thresholding,
    %% and display the decay of the energy \(J(x_j) = \norm{y_j-D x_j}^2\) for several \(j\).
    %% _Remark:_ note that the iteration can be performed in parallel on all
    %% \(x_j\).
    disp('Iterative thresholding')
    niter = 100;
    gamma = 1.6/norm(D)^2;
    E = [];
    X = zeros(p,np);
    for i=1:niter
        R = D*X-Y;
        E(end+1,:) = sum(R.^2);
        X = ProjX(X - gamma * D'*R, k);
    end
%     sel = 1:5;
%     clf;
%     plot(log10(E(1:end/2,sel) - repmat(min(E(:,sel),[],1),[niter/2 1])  ));
%     axis tight;
%     title('log_{10}(J(x_j) - J(x_j^*))');
%     
%     %EXO
%     %% Perform this gradient descent, and monitor the decay of the energy.
    niter_dico = 100;
    E = [];
    tau = 1/norm(X*X');
    for i=1:niter_dico
        R = D*X - Y;
        E(end+1) = sum(R(:).^2);
        D = ProjC( D + tau * (Y-D*X)*X' );
    end
%     clf;
%     plot(log10(E(1:end/2)-min(E)));
%     axis tight;
%     %EXO
%     
    
    %EXO
    %% Perform the dictionary learning by iterating between sparse coding and
    %% dictionary update.
    disp('dictionary learning')
    niter_learning = 10;
    niter_dico = 50;
    niter_coef = 100;
    E0 = [];
    X = zeros(p,np);
    D = D0;
    for iter = 1:niter_learning
        % --- coefficient update ----
        E = [];
        gamma = 1.6/norm(D)^2;
        for i=1:niter
            R = D*X - Y;
            E(end+1,:) = sum(R.^2);
            X = ProjX(X - gamma * D'*R, k);
        end
        E0(end+1) = norm(Y-D*X, 'fro')^2;
        % --- dictionary update ----
        E = [];
        tau = 1/norm(X*X');
        for i=1:niter_dico
            R = D*X - Y;
            E(end+1) = sum(R(:).^2);
            D = ProjC( D - tau * (D*X - Y)*X' );
        end
        E0(end+1) = norm(Y-D*X, 'fro')^2;
    end
%     clf; hold on;
%     plot(1:2*niter_learning, E0);
%     plot(1:2:2*niter_learning, E0(1:2:2*niter_learning), '*');
%     plot(2:2:2*niter_learning, E0(2:2:2*niter_learning), 'o');
%     axis tight;
%     legend('|Y-DX|^2', 'After coefficient update', 'After dictionary update');
    %EXO
end
return

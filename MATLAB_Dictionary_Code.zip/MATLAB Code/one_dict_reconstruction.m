function  out = one_dict_reconstruction(y,w,lambda,dict_path)


load (dict_path,'D');
%load (dict_path,'D');

y1 = y/max(abs(y));

[res,ftot_min,ites] = iterative_den(y1,lambda,D,w,100,1e-1,1);

out.res = res;
out.glitch = ftot_min;

function D = dictionary_creation(data_den,p_size,p_origin,d_size,np)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% data_den: data with the catalog (organized as columns)
% p_size: size of the window to get patches (one side)
% p_origin: sample around the patches are selected
% d_size: dictionary size (lenght of the patches)
% np: number of patches
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Select random blips for training and test
[n,m] = size(data_den)

training = 1:60;


%% Select window to obtain patches

%window = p_origin-p_size/2:p_origin+3*p_size/2-1;


%% Create dictionary

%X = data_den(window,training);
X = data_den();


% Normalization
for i=1:size(X,2)
    X(:,i) = X(:,i)/max(abs(X(:,i)));
end


D=create_dictionary(X,d_size,np,'random',1);

dic_name=strcat('D_CBC_',num2str(p_size),'w',num2str(d_size),'np',num2str(np))
save (dic_name, 'D')


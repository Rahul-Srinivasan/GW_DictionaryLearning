function [res,ftot,iter] = iterative_den(y1,lambda,D,w,maxiter,tol,normalize)
% y1: input signal to denoise
%lambda: regularization parameter
%D: dictionary to denoise
%w: sliding window size
%maxiter: maximum number of iterations 
%tol: tolerance
%normalize: 1 (true) o 0(false) in case the input signal has to be
%normalized or not
rt=max(abs(y1));
if normalize
    y1=y1./rt;
end
        
%tol= 1e-3;
error = 1000;
res = y1(:);
iter = 0;
ftot = zeros(size(y1(:)));
while error>tol && iter<maxiter
    res_old = res;
    [f,ftv,f1]=dict_denoising(res(:),D,w,max(w/8,2),lambda); %w/8 para el step parace razonable
    ftot = ftot(:)+f(:);
    res= res(:)-f(:);
    error = norm(res-res_old);
    iter=iter+1;
    %fprintf('Iter %i - Error: %g\n',iter,error);
end
return

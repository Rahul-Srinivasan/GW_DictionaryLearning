function [f,ftv,f1]=patch_averaging2(Y_i,Y,l)

f = zeros(1,l);
[m,n]=size(Y);
my = f;
aux = ones(1,m);
for i=1:n
    f(Y_i(:,i))=  f(Y_i(:,i)) + Y(:,i)';
    my(Y_i(:,i))= my(Y_i(:,i))+ aux;

end
f = f./my;
ftv = zeros(1,l);
f1 = ftv;
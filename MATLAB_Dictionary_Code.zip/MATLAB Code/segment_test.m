 function [Y,Y_i]=segment_test(x,w,q)
%disp('Segmenting data')
%%Segment the data to perform the paralell denoising
% x% data to segmentize
% w: length of the patch
% q% overlaping between patches
Y_i=buffer(1:length(x),w,q,'nodelay');
Y=buffer(x,w,q,'nodelay');
% i=find(Y_i(:,end)==0,1,'last')
if Y_i(end,end)==0
    Y_i(:,end)=[];
    Y(:,end)=[];
end
% Y(:,1:i-1)=[];
% Y_i(:,1:i-1)=[];
theta = mean(Y);
Y = Y - repmat( theta, [w 1] );